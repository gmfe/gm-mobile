import React from 'react'
import { View } from '../view'
import { Page } from '.'

export const normal = () => {
  return (
    <Page
      header={<View>header</View>}
      tabbar={<View>tabbar</View>}
      top={<View>top</View>}
      bottom={<View>bottom</View>}
    >
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
      <View>da</View>
    </Page>
  )
}

export const loading = () => {
  return <Page loading>loading</Page>
}

export const error = () => {
  return <Page error>error</Page>
}

export default {
  title: '布局/Page',
  component: Page,
}
